import fetch from "node-fetch";

const SYSTEM_PROMPT = `You are VMG Studios BK's concierge. Goals:
1) Be fast, confident, and helpful.
2) Convert visitors: capture name, email, phone, preferred service, budget, desired date/time.
3) Push booking link when user shows intent.
4) Offer upsells: content shoot add-on, mix/master bundle, membership.
5) Answer FAQs about VMG (see knowledge). If unknown, say you'll pass to a human and collect contact.

Knowledge:
- Brand: VMG Studios BK – recording studio & content space in Brooklyn, NY.
- Address: 855 Humboldt St, Brooklyn, NY 11222 (Greenpoint/Williamsburg border).
- Core services: Recording (engineer included), Mixing, Mastering, Content Shoots, Podcast, Rehearsal.
- Example baseline rates (update as needed): Recording $50–$70/hr; Mixing $150/song; Mastering $80/song; Content add-on $60/hr.
- Promos: Grand Opening promos may be active; confirm current offer.
- Booking: Online only via BOOKING_URL. Walk-ins not guaranteed.
- Turnaround: Same-day sessions when available. Mix/master 24–72h typical.
- Payment: Card or deposit required for bookings. Deposits non-refundable but transferable once with 24h notice.
- Social: IG @Vmg_Studios_.
- Brand voice: billionaire operator, crisp, ROI-minded, zero fluff.

Always end messages with a short CTA when appropriate (e.g., "Want the booking link?" or "Can I lock a slot for you?"). Keep answers under 120 words.`;

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Use POST" });
  }

  try {
    const { messages, lead } = await parseBody(req);
    const openaiKey = process.env.OPENAI_API_KEY;
    if (!openaiKey) throw new Error("Missing OPENAI_API_KEY");

    const userLead = normalizeLead(lead);
    const bookingUrl = process.env.BOOKING_URL || "https://example.com/book";

    // Tool: lead_capture – the model can ask us to store a lead
    const tools = [{
      type: "function",
      function: {
        name: "lead_capture",
        description: "Store a qualified lead and return a confirmation message.",
        parameters: {
          type: "object",
          properties: {
            name: { type: "string" },
            email: { type: "string" },
            phone: { type: "string" },
            service: { type: "string" },
            budget: { type: "string" },
            datetime: { type: "string" },
            notes: { type: "string" }
          },
          required: []
        }
      }
    }];

    const body = {
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: SYSTEM_PROMPT.replace("BOOKING_URL", bookingUrl) },
        ...(userLead ? [{
          role: "system",
          content: `Current visitor lead data: ${JSON.stringify(userLead)}`
        }] : []),
        ...messages
      ],
      tools
    };

    const ai = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openaiKey}`
      },
      body: JSON.stringify(body)
    }).then(r => r.json());

    // If the model asked to call our lead_capture tool:
    const toolCall = ai?.choices?.[0]?.message?.tool_calls?.find(t => t.function?.name === "lead_capture");
    if (toolCall) {
      let payload = {};
      try {
        payload = JSON.parse(toolCall.function.arguments || "{}");
      } catch {}
      await forwardLead({ ...userLead, ...payload });
    }

    const reply = ai?.choices?.[0]?.message?.content || "All set. Want the booking link?";
    res.status(200).json({ reply, bookingUrl });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err?.message || err) });
  }
}

async function parseBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", chunk => data += chunk);
    req.on("end", () => {
      try {
        const parsed = JSON.parse(data || "{}");
        resolve(parsed);
      } catch (e) {
        reject(e);
      }
    });
  });
}

function normalizeLead(lead) {
  if (!lead) return null;
  const out = {};
  ["name","email","phone","service","budget","datetime","notes"].forEach(k => {
    if (lead[k]) out[k] = String(lead[k]).trim();
  });
  return Object.keys(out).length ? out : null;
}

async function forwardLead(payload) {
  const hook = process.env.ZAPIER_WEBHOOK_URL;
  if (!hook) return;
  try {
    await fetch(hook, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ source: "vmg-chatbot", timestamp: new Date().toISOString(), ...payload })
    });
  } catch (e) {
    console.error("Lead forward failed", e);
  }
}
