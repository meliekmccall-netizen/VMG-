# VMG Chatbot (Website + API)

A lightweight, Vercel‑ready chatbot for VMG Studios BK that captures leads, answers FAQs, and pushes users to book sessions.

## What you get
- Public site with a floating chat widget
- Serverless `/api/chat` endpoint using OpenAI
- Lead capture (name, email, phone, preferred service)
- Intent routing for: Booking, Quotes, AI Rapper Demo, Sync Licensing, Classes
- Webhook out to Zapier/Make (optional)

## One‑time setup (10 minutes)
1. Install the Vercel CLI: `npm i -g vercel` (optional—you can also import the folder at vercel.com)
2. In the Vercel dashboard, set **Environment Variables**:
   - `OPENAI_API_KEY` = your OpenAI key
   - `ZAPIER_WEBHOOK_URL` (optional) = a catch‑hook URL to send leads
   - `BOOKING_URL` = your Square/Calendly booking link
3. Deploy:
   - Zip this folder or push to GitHub and **Import** into Vercel
   - Or use CLI: `vercel` then `vercel --prod`

## Local dev
```
npm install
vercel dev
```
Visit http://localhost:3000

## Files
- `public/index.html` – UI
- `api/chat.js` – Chat endpoint
- `vercel.json` – Build + routes

## Customize the assistant
Edit the SYSTEM_PROMPT in `api/chat.js` to update pricing, address, services, or tone.

## Data & compliance
- The API stores nothing by default; it forwards leads to `ZAPIER_WEBHOOK_URL` if provided.
- Add your privacy link in the widget footer.
